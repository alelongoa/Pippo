using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace EbanisNumeratore {
 static class Program {
  [STAThread] static void Main(){ Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false); Application.Run(new MainWindow()); }
 }
 class ModulePlan { public DirectoryInfo Dir; public int Index; public List<FileInfo> Files; public string NewName; }
 class JobPlan { public DirectoryInfo Job; public List<ModulePlan> Modules; public string NewName; public int FileCount { get { return Modules.Sum(m=>m.Files.Count); } } }
 class MainWindow: Form {
  Color gold=Color.FromArgb(184,148,84), dark=Color.FromArgb(24,23,22), panel=Color.FromArgb(36,34,32), cream=Color.FromArgb(248,246,242);
  TextBox path,info; ListBox jobs; TreeView tree; Button start, labelsButton; List<DirectoryInfo> jobList=new List<DirectoryInfo>(); JobPlan current;
  string basePath="", configFile=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"EbanisNumeratoreEXE","percorso.txt");
  string asset(string name){return Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Assets",name);}
  public MainWindow(){
   Text="EBANIS | Numeratore Moduli"; ClientSize=new Size(1180,765); MinimumSize=new Size(1090,740); StartPosition=FormStartPosition.CenterScreen; BackColor=dark; ForeColor=Color.White; Font=new Font("Segoe UI",10);
   try { Icon=new Icon(asset("Numeratore_Moduli.ico")); }catch{}
   var hero=new Panel{Bounds=new Rectangle(0,0,1180,194),BackColor=dark,Anchor=AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Top};Controls.Add(hero);
   var photo=new PictureBox{Bounds=new Rectangle(270,0,910,194),SizeMode=PictureBoxSizeMode.Zoom,Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right}; try{photo.Image=Image.FromFile(asset("foto_progetto_ebanis.jpg"));}catch{}hero.Controls.Add(photo);
   var overlay=new Panel{Bounds=new Rectangle(280,8,710,176),BackColor=Color.FromArgb(36,34,32)};hero.Controls.Add(overlay);overlay.BringToFront();
   var logo=new PictureBox{Bounds=new Rectangle(17,10,208,170),BackColor=Color.White,SizeMode=PictureBoxSizeMode.Zoom};try{logo.Image=Image.FromFile(asset("logo_ebanis.png"));}catch{}hero.Controls.Add(logo);logo.BringToFront();
   overlay.Controls.Add(lbl("NUMERATORE MODULI",20,12,630,53,25,Color.White,true));
   overlay.Controls.Add(lbl("EBANIS  |  CREAZIONI IN LEGNO",24,73,620,30,13,gold,true));
   overlay.Controls.Add(lbl("Organizza e rinomina cartelle e file dei tuoi lavori",24,116,650,30,11,Color.White,false));
   Controls.Add(lbl("01  CARTELLA DEI LAVORI",24,207,500,30,13,gold,true));
   path=new TextBox{Bounds=new Rectangle(24,244,923,34),ReadOnly=true,BackColor=cream,ForeColor=dark,Font=new Font("Segoe UI",12),Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right};Controls.Add(path);
   var browse=btn("CAMBIA PERCORSO",965,243,191,36,panel,gold);browse.Anchor=AnchorStyles.Top|AnchorStyles.Right;Controls.Add(browse);browse.Click+=(s,e)=>ChooseFolder();
   Controls.Add(lbl("02  SELEZIONA IL LAVORO",24,297,360,28,12,gold,true));
   Controls.Add(lbl("03  ANTEPRIMA NUMERAZIONE",394,297,440,28,12,gold,true));
   Controls.Add(lbl("INFORMAZIONI",875,297,280,28,12,gold,true));
   jobs=new ListBox{Bounds=new Rectangle(24,333,350,325),BackColor=cream,ForeColor=dark,Font=new Font("Segoe UI",11),IntegralHeight=false,Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Bottom};Controls.Add(jobs);jobs.SelectedIndexChanged+=(s,e)=>Preview();
   tree=new TreeView{Bounds=new Rectangle(394,333,460,325),BackColor=cream,ForeColor=dark,Font=new Font("Segoe UI",10),HideSelection=false,Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Bottom};Controls.Add(tree);
   info=new TextBox{Bounds=new Rectangle(875,333,281,325),BackColor=cream,ForeColor=dark,Font=new Font("Segoe UI",11),Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,Anchor=AnchorStyles.Top|AnchorStyles.Right|AnchorStyles.Bottom};Controls.Add(info);
   var refresh=btn("AGGIORNA",24,676,180,48,panel,Color.White);refresh.Anchor=AnchorStyles.Left|AnchorStyles.Bottom;Controls.Add(refresh);refresh.Click+=(s,e)=>RefreshJobs();
   start=btn("AVVIA NUMERAZIONE",394,676,460,48,gold,dark);start.Anchor=AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Bottom;Controls.Add(start);start.Click+=(s,e)=>Execute();
   labelsButton=btn("ETICHETTE",875,676,137,48,panel,gold);labelsButton.Anchor=AnchorStyles.Right|AnchorStyles.Bottom;Controls.Add(labelsButton);labelsButton.Click+=(s,e)=>OpenLabels();
   var close=btn("CHIUDI",1020,676,136,48,panel,Color.White);close.Anchor=AnchorStyles.Right|AnchorStyles.Bottom;Controls.Add(close);close.Click+=(s,e)=>Close();
   try{if(File.Exists(configFile))basePath=File.ReadAllText(configFile).Trim();}catch{} RefreshJobs();
  }
  Label lbl(string t,int x,int y,int w,int h,int size,Color c,bool bold){return new Label{Text=t,Bounds=new Rectangle(x,y,w,h),Font=new Font("Segoe UI",size,bold?FontStyle.Bold:FontStyle.Regular),ForeColor=c,BackColor=Color.Transparent};}
  Button btn(string t,int x,int y,int w,int h,Color bg,Color fg){var b=new Button{Text=t,Bounds=new Rectangle(x,y,w,h),BackColor=bg,ForeColor=fg,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",10,FontStyle.Bold),Cursor=Cursors.Hand};b.FlatAppearance.BorderColor=gold;return b;}
  static bool Numbered(string name){return Regex.IsMatch(name,@"^\s*\d+\s*-\s*");}
  void ChooseFolder(){using(var d=new FolderBrowserDialog{Description="Scegli la cartella contenente i lavori"}){if(Directory.Exists(basePath))d.SelectedPath=basePath;if(d.ShowDialog(this)==DialogResult.OK){basePath=d.SelectedPath;try{Directory.CreateDirectory(Path.GetDirectoryName(configFile));File.WriteAllText(configFile,basePath);}catch(Exception ex){MessageBox.Show("Impossibile salvare il percorso: "+ex.Message);}RefreshJobs();}}}
  void RefreshJobs(){jobs.Items.Clear();tree.Nodes.Clear();current=null;info.Text="";jobList.Clear();path.Text=basePath;
   if(!Directory.Exists(basePath)){info.Text="Seleziona la cartella che contiene i lavori.";return;}
   try{jobList= new DirectoryInfo(basePath).GetDirectories().OrderBy(d=>d.Name,StringComparer.CurrentCultureIgnoreCase).ToList();foreach(var j in jobList)jobs.Items.Add(j.Name);info.Text="Lavori trovati: "+jobList.Count+"\r\n\r\nSeleziona un lavoro.\r\n\r\nLa numerazione riparte da 1 a ogni operazione.";}catch(Exception ex){info.Text=ex.Message;}
  }
  JobPlan BuildPlan(DirectoryInfo job){
   if(Numbered(job.Name))throw new Exception("La cartella del lavoro e' gia' numerata.");
   var mods=job.GetDirectories().OrderBy(d=>d.Name,StringComparer.CurrentCultureIgnoreCase).ToList();if(mods.Count==0)throw new Exception("Il lavoro non contiene cartelle di moduli.");
   var plan=new JobPlan{Job=job,Modules=new List<ModulePlan>(),NewName="1-"+job.Name};
   if(Directory.Exists(Path.Combine(job.Parent.FullName,plan.NewName)))throw new Exception("Esiste gia' il lavoro: "+plan.NewName);
   int i=0;foreach(var mod in mods){i++;if(Numbered(mod.Name))throw new Exception("Modulo gia' numerato: "+mod.Name);
    if(mod.GetDirectories().Length>0)throw new Exception("Sottocartelle non supportate nel modulo: "+mod.Name);
    var files=mod.GetFiles().OrderBy(f=>f.Name,StringComparer.CurrentCultureIgnoreCase).ToList();foreach(var f in files){if(Numbered(f.Name))throw new Exception("File gia' numerato: "+f.Name);
     if(File.Exists(Path.Combine(mod.FullName,i+" - "+f.Name)))throw new Exception("Conflitto con file: "+f.Name);
    }
    string newName=i+"-"+mod.Name;if(Directory.Exists(Path.Combine(job.FullName,newName)))throw new Exception("Conflitto con modulo: "+newName);
    plan.Modules.Add(new ModulePlan{Dir=mod,Index=i,Files=files,NewName=newName});
   }return plan;
  }
  void Preview(){tree.Nodes.Clear();current=null;if(jobs.SelectedIndex<0||jobs.SelectedIndex>=jobList.Count)return;
   try{current=BuildPlan(jobList[jobs.SelectedIndex]);var root=tree.Nodes.Add(current.NewName);foreach(var m in current.Modules){var node=root.Nodes.Add(m.NewName);foreach(var f in m.Files)node.Nodes.Add(m.Index+" - "+f.Name);}root.Expand();info.Text="Lavoro:\r\n"+current.Job.Name+"\r\n\r\nModuli: "+current.Modules.Count+"\r\nFile: "+current.FileCount+"\r\n\r\nCartella finale:\r\n"+current.NewName+"\r\n\r\nModifica gli originali.\r\nConserva tutte le estensioni.";}
   catch(Exception ex){info.Text="OPERAZIONE BLOCCATA\r\n\r\n"+ex.Message;}
  }
  void OpenLabels(){
   if(!Directory.Exists(basePath)){MessageBox.Show(this,"Seleziona prima la cartella dei lavori.","EBANIS");return;}
   using(var ed=new LabelEditor(basePath)){ed.ShowDialog(this);}
  }
  void Execute(){if(current==null){MessageBox.Show(this,"Seleziona un lavoro valido.","EBANIS");return;}
   var name=current.Job.Name;var answer=MessageBox.Show(this,"Rinominare direttamente il lavoro '"+name+"'?\r\n\r\n"+current.Modules.Count+" moduli e "+current.FileCount+" file.\r\n\r\nL'operazione non crea copie e non dispone di annullamento automatico.\r\nEsegui prima un backup.","Conferma numerazione",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
   if(answer!=DialogResult.Yes)return;
   try{var p=BuildPlan(new DirectoryInfo(current.Job.FullName));
    // Record every completed move, so a failure can be rolled back in reverse order.
    var completed=new List<string[]>();
    try {
     foreach(var m in p.Modules)foreach(var f in m.Files){string dest=Path.Combine(m.Dir.FullName,m.Index+" - "+f.Name);File.Move(f.FullName,dest);completed.Add(new[]{dest,f.FullName,"file"});}
     foreach(var m in p.Modules){string dest=Path.Combine(p.Job.FullName,m.NewName);Directory.Move(m.Dir.FullName,dest);completed.Add(new[]{dest,m.Dir.FullName,"dir"});}
     string finalPath=Path.Combine(p.Job.Parent.FullName,p.NewName);Directory.Move(p.Job.FullName,finalPath);completed.Add(new[]{finalPath,p.Job.FullName,"dir"});
    }catch(Exception err){
     var failed=new List<string>();
     for(int i=completed.Count-1;i>=0;i--){var step=completed[i];try{if(step[2]=="file")File.Move(step[0],step[1]);else Directory.Move(step[0],step[1]);}catch(Exception rollbackError){failed.Add(step[0]+": "+rollbackError.Message);}}
     throw new Exception("Rinomina interrotta: "+err.Message+(failed.Count==0?". Le operazioni precedenti sono state ripristinate.":". Ripristino incompleto: "+String.Join("; ",failed.ToArray())));
    }
    MessageBox.Show(this,"Numerazione completata.\r\n\r\n"+p.Modules.Count+" moduli e "+p.FileCount+" file.\r\n\r\n"+p.NewName,"EBANIS",MessageBoxButtons.OK,MessageBoxIcon.Information);
   }catch(Exception ex){MessageBox.Show(this,"Operazione interrotta: "+ex.Message+"\r\n\r\nATTENZIONE: alcune rinomine potrebbero essere gia' state eseguite. Controlla la cartella.","Errore",MessageBoxButtons.OK,MessageBoxIcon.Error);}finally{RefreshJobs();}
  }
 }
}
