using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Text;

namespace EbanisNumeratore {
 class LabelRecord { public string Project,Module,Filename,Path,Dimensions; public override string ToString(){return Module+"  /  "+Filename;} }
 class LabelEditor:Form {
  readonly Color dark=Color.FromArgb(24,23,22),gold=Color.FromArgb(197,161,107);
  readonly string root,settingsPath;
  ComboBox job,module,file,scope,paper; Panel preview; Label counter; Button modify;
  CheckBox showBrand,showJob,showModule,showDims,showExtra; TextBox extra; NumericUpDown font;
  Panel editor; List<LabelRecord> records=new List<LabelRecord>(),selection=new List<LabelRecord>();
  PrintDocument doc=new PrintDocument(); int printIndex=0, previewIndex=0;
  public LabelEditor(string rootPath){
   root=rootPath;settingsPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"EbanisNumeratoreEXE","modello.cfg");
   Text="EBANIS | Anteprima e stampa etichette";StartPosition=FormStartPosition.CenterParent;ClientSize=new Size(880,850);MinimumSize=new Size(790,750);AutoScroll=true;BackColor=dark;ForeColor=Color.White;Font=new Font("Segoe UI",10);
   int y=18; AddTitle("2 · ANTEPRIMA ETICHETTA",20,y);y+=44;
   preview=new Panel{Left=20,Top=y,Width=810,Height=248,BackColor=Color.White,Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right};Controls.Add(preview);preview.Paint+=(s,e)=>DrawLabel(e.Graphics,new RectangleF(18,10,preview.Width-36,preview.Height-20),Current());y+=258;
   var before=Button("◀ PRECEDENTE",20,y,165);before.Click+=(s,e)=>{previewIndex=Math.Max(0,previewIndex-1);UpdateSelection();};
   var after=Button("SUCCESSIVA ▶",200,y,165);after.Click+=(s,e)=>{previewIndex=Math.Min(selection.Count-1,previewIndex+1);UpdateSelection();};
   counter=Label("",385,y+8,440,30);y+=59;
   AddTitle("3 · OPZIONI DI STAMPA",20,y);y+=42;
   Label("Lavoro",20,y,160,25);job=Drop(180,y,630);job.SelectedIndexChanged+=(s,e)=>LoadJob();y+=42;
   Label("Modulo",20,y,160,25);module=Drop(180,y,630);module.SelectedIndexChanged+=(s,e)=>UpdateFiles();y+=42;
   Label("Etichette",20,y,160,25);scope=Drop(180,y,630);scope.Items.AddRange(new object[]{"Tutti i file del modulo","Tutti i file del lavoro","Un solo file"});scope.SelectedIndex=0;scope.SelectedIndexChanged+=(s,e)=>UpdateSelection();y+=42;
   Label("File",20,y,160,25);file=Drop(180,y,630);file.SelectedIndexChanged+=(s,e)=>UpdateSelection();y+=42;
   Label("Formato",20,y,160,25);paper=Drop(180,y,630);paper.Items.AddRange(new object[]{"A4 - 2 colonne × 6 righe","Termica - 100 × 60 mm"});paper.SelectedIndex=0;y+=46;
   var print=Button("STAMPA / SALVA PDF",20,y,270);print.BackColor=gold;print.ForeColor=dark;print.Click+=(s,e)=>Print(false);
   var previewPrint=Button("ANTEPRIMA DI STAMPA",310,y,260);previewPrint.Click+=(s,e)=>Print(true);y+=70;
   AddTitle("4 · MODIFICA ETICHETTA",20,y);y+=40;
   modify=Button("✎ MODIFICA ETICHETTA",20,y,790);modify.Click+=(s,e)=>{editor.Visible=!editor.Visible;};y+=56;
   editor=new Panel{Left=20,Top=y,Width=790,Height=180,Visible=false,BackColor=Color.FromArgb(38,37,35)};Controls.Add(editor);
   showBrand=Check("Logo EBANIS",10,10,true);showJob=Check("Nome lavoro",210,10,true);showModule=Check("Nome modulo",410,10,true);showDims=Check("Dimensioni",610,10,true);
   showExtra=Check("Testo aggiuntivo",10,47,false);extra=new TextBox{Left=210,Top=47,Width=380};editor.Controls.Add(extra);
   editor.Controls.Add(new Label{Left=10,Top=92,Width=220,Text="Dimensione caratteri",ForeColor=Color.White});font=new NumericUpDown{Left=230,Top=90,Width=90,Minimum=8,Maximum=18,Value=11};editor.Controls.Add(font);
   var save=new Button{Text="SALVA MODELLO",Left=410,Top=90,Width=175,Height=34,BackColor=gold,ForeColor=dark};editor.Controls.Add(save);save.Click+=(s,e)=>SaveSettings();
   var reset=new Button{Text="RIPRISTINA",Left=600,Top=90,Width=165,Height=34};editor.Controls.Add(reset);reset.Click+=(s,e)=>{showBrand.Checked=showJob.Checked=showModule.Checked=showDims.Checked=true;showExtra.Checked=false;extra.Text="";font.Value=11;SaveSettings();};
   editor.Controls.Add(new Label{Left=10,Top=142,Width=750,Height=30,ForeColor=Color.Gainsboro,Text="Nome del file e codice a barre non sono modificabili. Il materiale non viene stampato."});
   foreach(var cb in new[]{showBrand,showJob,showModule,showDims,showExtra})cb.CheckedChanged+=(s,e)=>preview.Invalidate();extra.TextChanged+=(s,e)=>preview.Invalidate();font.ValueChanged+=(s,e)=>preview.Invalidate();
   doc.BeginPrint+=(s,e)=>printIndex=0;doc.PrintPage+=PrintPage;
   LoadSettings();LoadJobs();
  }
  Label Label(string s,int x,int y,int w,int h){var l=new Label{Text=s,Left=x,Top=y,Width=w,Height=h,ForeColor=Color.White};Controls.Add(l);return l;}
  void AddTitle(string s,int x,int y){var l=Label(s,x,y,800,36);l.ForeColor=gold;l.Font=new Font("Segoe UI",15,FontStyle.Bold);}
  Button Button(string s,int x,int y,int w){var b=new Button{Text=s,Left=x,Top=y,Width=w,Height=38,BackColor=Color.FromArgb(45,43,40),ForeColor=gold,FlatStyle=FlatStyle.Flat};b.FlatAppearance.BorderColor=gold;Controls.Add(b);return b;}
  ComboBox Drop(int x,int y,int w){var b=new ComboBox{Left=x,Top=y,Width=w,DropDownStyle=ComboBoxStyle.DropDownList};Controls.Add(b);return b;}
  CheckBox Check(string s,int x,int y,bool value){var c=new CheckBox{Text=s,Left=x,Top=y,Width=180,Height=29,Checked=value,ForeColor=Color.White};editor.Controls.Add(c);return c;}
  void LoadJobs(){job.Items.Clear();if(!Directory.Exists(root))return;foreach(var d in Directory.GetDirectories(root).OrderBy(p=>p,StringComparer.OrdinalIgnoreCase))if(System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(d),@"^\d+\s*-"))job.Items.Add(d);if(job.Items.Count>0)job.SelectedIndex=0;else MessageBox.Show(this,"Non ci sono lavori numerati. Esegui prima il numeratore.");}
  void LoadJob(){records.Clear();module.Items.Clear();file.Items.Clear();if(job.SelectedItem==null)return;
   try{string path=(string)job.SelectedItem;foreach(string d in Directory.GetDirectories(path).OrderBy(p=>p,StringComparer.OrdinalIgnoreCase)){
    string m=Path.GetFileName(d);module.Items.Add(m);foreach(string f in Directory.GetFiles(d).OrderBy(p=>p,StringComparer.OrdinalIgnoreCase))records.Add(new LabelRecord{Project=Path.GetFileName(path),Module=m,Filename=Path.GetFileName(f),Path=f,Dimensions=Dimensions.Read(f)});
   }if(module.Items.Count>0)module.SelectedIndex=0;else UpdateSelection();}catch(Exception ex){MessageBox.Show(this,"Errore lettura lavoro: "+ex.Message);}
  }
  void UpdateFiles(){file.Items.Clear();if(module.SelectedItem==null){UpdateSelection();return;}foreach(var r in records.Where(r=>r.Module==(string)module.SelectedItem))file.Items.Add(r.Filename);if(file.Items.Count>0)file.SelectedIndex=0;else UpdateSelection();}
  void UpdateSelection(){selection.Clear();if(scope.SelectedIndex==1)selection.AddRange(records);else if(module.SelectedItem!=null){selection.AddRange(records.Where(r=>r.Module==(string)module.SelectedItem&&(scope.SelectedIndex!=2||r.Filename==(string)file.SelectedItem)));}
   previewIndex=Math.Max(0,Math.Min(previewIndex,selection.Count-1));counter.Text=selection.Count==0?"Nessuna etichetta":String.Format("Etichetta {0} di {1} · {1} da stampare",previewIndex+1,selection.Count);preview.Invalidate();}
  LabelRecord Current(){return selection.Count==0?null:selection[previewIndex];}
  void DrawLabel(Graphics g,RectangleF area,LabelRecord r){
   g.FillRectangle(Brushes.White,area);if(r==null){g.DrawString("Seleziona un lavoro e un modulo",Font,Brushes.Black,area.Left+12,area.Top+20);return;}
   float x=area.Left+12,y=area.Top+8;using(var brand=new Font("Segoe UI",18,FontStyle.Bold))using(var normal=new Font("Segoe UI",(float)font.Value))using(var strong=new Font("Segoe UI",(float)font.Value+3,FontStyle.Bold)){
    if(showBrand.Checked){g.DrawString("EBANIS",brand,new SolidBrush(Color.FromArgb(169,129,69)),x,y);y+=31;}
    if(showJob.Checked){g.DrawString("Lavoro: "+r.Project,normal,Brushes.Black,x,y);y+=21;}
    if(showModule.Checked){g.DrawString("Modulo: "+r.Module,normal,Brushes.Black,x,y);y+=21;}
    g.DrawString(r.Filename,strong,Brushes.Black,new RectangleF(x,y,area.Width-20,25));y+=28;
    if(showDims.Checked){g.DrawString(r.Dimensions,strong,Brushes.Black,x,y);y+=28;}
    if(showExtra.Checked&&!String.IsNullOrWhiteSpace(extra.Text)){g.DrawString(extra.Text,normal,Brushes.Black,x,y);y+=21;}
    float barcodeHeight=Math.Min(56,Math.Max(18,area.Bottom-y-21));if(barcodeHeight>0){try{Code128.Draw(g,r.Filename,new RectangleF(x,y,area.Width-25,barcodeHeight));}catch(Exception){g.DrawString("Caratteri non supportati dal Code 128",normal,Brushes.DarkRed,x,y);}y+=barcodeHeight+2;}
    using(var small=new Font("Segoe UI",8))g.DrawString(r.Filename,small,Brushes.Black,new RectangleF(x,y,area.Width-25,18));
   }
  }
  void Print(bool previewOnly){if(selection.Count==0){MessageBox.Show(this,"Seleziona almeno un file.");return;}
   foreach(var r in selection)try{Code128.Encode(r.Filename);}catch(Exception ex){MessageBox.Show(this,"Codice a barre non valido per "+r.Filename+": "+ex.Message);return;}
   printIndex=0;try{if(previewOnly){using(var d=new PrintPreviewDialog{Document=doc,Width=1000,Height=760})d.ShowDialog(this);}else{using(var d=new PrintDialog{Document=doc,UseEXDialog=true})if(d.ShowDialog(this)==DialogResult.OK)doc.Print();}}catch(Exception ex){MessageBox.Show(this,"Errore stampa: "+ex.Message);}
  }
  void PrintPage(object sender,PrintPageEventArgs e){var g=e.Graphics;var area=e.MarginBounds;bool thermal=paper.SelectedIndex==1;
   if(thermal){ // Set matching custom media size in printer driver before printing.
    DrawLabel(g,new RectangleF(area.Left,area.Top,Math.Min(area.Width,378),Math.Min(area.Height,227)),selection[printIndex]);printIndex++;
   }else{float gap=12;float w=(area.Width-gap)/2;float h=area.Height/6f;for(int n=0;n<12&&printIndex<selection.Count;n++,printIndex++){
     float x=area.Left+(n%2)*(w+gap),y=area.Top+(n/2)*h;
     g.DrawRectangle(Pens.LightGray,x,y,w,h-4);DrawLabel(g,new RectangleF(x+2,y+2,w-4,h-8),selection[printIndex]);
    }
   }e.HasMorePages=printIndex<selection.Count;
  }
  void SaveSettings(){try{Directory.CreateDirectory(Path.GetDirectoryName(settingsPath));File.WriteAllLines(settingsPath,new[]{showBrand.Checked.ToString(),showJob.Checked.ToString(),showModule.Checked.ToString(),showDims.Checked.ToString(),showExtra.Checked.ToString(),Convert.ToBase64String(Encoding.UTF8.GetBytes(extra.Text)),font.Value.ToString()});MessageBox.Show(this,"Modello etichetta salvato.");}catch(Exception ex){MessageBox.Show(this,ex.Message);}}
  void LoadSettings(){try{if(!File.Exists(settingsPath))return;var s=File.ReadAllLines(settingsPath);if(s.Length<7)return;showBrand.Checked=Boolean.Parse(s[0]);showJob.Checked=Boolean.Parse(s[1]);showModule.Checked=Boolean.Parse(s[2]);showDims.Checked=Boolean.Parse(s[3]);showExtra.Checked=Boolean.Parse(s[4]);extra.Text=Encoding.UTF8.GetString(Convert.FromBase64String(s[5]));font.Value=Math.Max(font.Minimum,Math.Min(font.Maximum,Decimal.Parse(s[6])));}catch{}}
 }
 static class Code128 {
  static readonly string[] P={"212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"};
  public static List<int> Encode(string s){if(String.IsNullOrEmpty(s))throw new Exception("Nome file vuoto.");var v=new List<int>{104};foreach(char c in s){int n=(int)c;if(n<32||n>126)throw new Exception("Il carattere '"+c+"' non è supportato dal Code 128 B ASCII.");v.Add(n-32);}int sum=104;for(int i=1;i<v.Count;i++)sum+=v[i]*i;v.Add(sum%103);v.Add(106);return v;}
  public static void Draw(Graphics g,string s,RectangleF box){var v=Encode(s);int units=20;foreach(int n in v)foreach(char c in P[n])units+=c-'0';float k=box.Width/units,x=box.Left+10*k;using(var ink=new SolidBrush(Color.Black))foreach(int n in v){bool bar=true;foreach(char c in P[n]){float w=(c-'0')*k;if(bar)g.FillRectangle(ink,x,box.Top,w,box.Height);x+=w;bar=!bar;}}}
 }
}
