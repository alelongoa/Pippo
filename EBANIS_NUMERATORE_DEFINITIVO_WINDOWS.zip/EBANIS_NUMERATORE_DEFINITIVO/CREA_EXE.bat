@echo off
setlocal
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if exist "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" (
 echo Compilatore .NET Framework non trovato. Installa .NET Framework 4.7.2 o superiore.
 pause
 exit /b 1
)
echo Creazione EBANIS_Numeratore_Moduli.exe...
"%CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /out:"EBANIS_Numeratore_Moduli.exe" /win32icon:"Assets\Numeratore_Moduli.ico" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Xml.dll /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll "Program.cs" "Labels.cs" "Dimensions.cs"
if errorlevel 1 (
 echo ERRORE compilazione. Invia la schermata dell'errore.
 pause
 exit /b 1
)
echo.
echo Programma creato: EBANIS_Numeratore_Moduli.exe
pause
