using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Globalization;

namespace EbanisNumeratore {
 static class Dimensions {
  public static string Read(string path) {
   try {
    string ext=Path.GetExtension(path).ToLowerInvariant();
    if(ext==".cnc"||ext==".txt"||ext==".text")return ReadCnc(path);
    if(ext==".pgmx")return ReadPgmx(path);
   } catch {} return "Misure non disponibili";
  }
  static string ReadCnc(string path){
   string data=File.ReadAllText(path); var section=Regex.Match(data,@"(?ims)^\s*\[PARAMETRI01\]\s*(.*?)(?=^\s*\[|\z)");
   if(!section.Success)return "Misure non disponibili";
   string s=section.Groups[1].Value; string x=Val(s,"LX"),y=Val(s,"LY"),z=Val(s,"PLPZ");
   if(x==null||y==null||z==null)return "Misure non disponibili";
   return x+" × "+y+" × "+z+" mm";
  }
  static string Val(string s,string key){var m=Regex.Match(s,@"(?i)(?<![A-Z0-9_])"+Regex.Escape(key)+@"\s*=\s*(\d+(?:[.,]\d+)?)");if(!m.Success)return null;decimal d;if(!decimal.TryParse(m.Groups[1].Value.Replace(',','.'),NumberStyles.Number,CultureInfo.InvariantCulture,out d)||d<=0)return null;return d.ToString("0.###",CultureInfo.InvariantCulture);}
  static string ReadPgmx(string path){
   // Maestro PGMX is version-dependent. Only accept a real ZIP container with a recognized Workpiece XML element.
   using(var fs=File.OpenRead(path)){
    if(fs.Length<4||fs.ReadByte()!=0x50||fs.ReadByte()!=0x4B)return "Misure non disponibili";
    fs.Position=0;
    using(var zip=new ZipArchive(fs,ZipArchiveMode.Read)){
     foreach(var entry in zip.Entries.Where(e=>e.FullName.EndsWith(".xml",StringComparison.OrdinalIgnoreCase)).Take(100)){
      if(entry.Length>8*1024*1024)continue;
      using(var stream=entry.Open())using(var reader=XmlReader.Create(stream,new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null})){
       while(reader.Read())if(reader.NodeType==XmlNodeType.Element&&reader.LocalName.Equals("Workpiece",StringComparison.OrdinalIgnoreCase)){
        string a=Numeric(reader.GetAttribute("Length")),b=Numeric(reader.GetAttribute("Width")),c=Numeric(reader.GetAttribute("Thickness"));
        if(a!=null&&b!=null&&c!=null)return a+" × "+b+" × "+c+" mm";
       }
      }
     }
    }
   }
   return "Misure non disponibili";
  }
  static string Numeric(string s){if(s==null)return null;decimal d;if(!decimal.TryParse(s.Replace(',','.'),NumberStyles.Number,CultureInfo.InvariantCulture,out d)||d<=0)return null;return d.ToString("0.###",CultureInfo.InvariantCulture);}
 }
}
